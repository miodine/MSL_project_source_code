var _m_s__signal__control_8c =
[
    [ "compensate_error", "_m_s__signal__control_8c.html#a6fdf7020f344d899c73f618ce8567d75", null ],
    [ "encoder_RPM_duty_update", "_m_s__signal__control_8c.html#a21304f9f79e0331930665e4d23892e4f", null ],
    [ "get_RPM_actual", "_m_s__signal__control_8c.html#ae109753ed1798aa1c854b69978d00e85", null ],
    [ "increment_counter_at_tacho_ev", "_m_s__signal__control_8c.html#afc36ab908fdadfe06cf7a6b3e1c0f7da", null ],
    [ "read_PWM_duty", "_m_s__signal__control_8c.html#aa68db16714a58a700eceb3ddc19c1db6", null ],
    [ "set_PWM_from_RPM", "_m_s__signal__control_8c.html#a41e6d6d32d2de1cfa657572ece0883ff", null ],
    [ "set_reference_RPM", "_m_s__signal__control_8c.html#a060ebfa3cd7dac5cd16c131af0c1c9c9", null ],
    [ "update_PWM_duty", "_m_s__signal__control_8c.html#a8d5c4f04683ef2370133c6582e1a18b5", null ]
];