var searchData=
[
  ['increment_5fcounter_5fat_5ftacho_5fev_39',['increment_counter_at_tacho_ev',['../_m_s__signal__control_8c.html#afc36ab908fdadfe06cf7a6b3e1c0f7da',1,'increment_counter_at_tacho_ev(Program_Data *pd):&#160;MS_signal_control.c'],['../_m_s__signal__control_8h.html#afc36ab908fdadfe06cf7a6b3e1c0f7da',1,'increment_counter_at_tacho_ev(Program_Data *pd):&#160;MS_signal_control.c']]],
  ['initialize_5fstm32_5finterfaces_40',['initialize_STM32_interfaces',['../_m_s__core_8c.html#a657993cab1db72a4e524d79ab3987a2a',1,'initialize_STM32_interfaces(Program_Data *pd):&#160;MS_core.c'],['../_m_s__core_8h.html#a657993cab1db72a4e524d79ab3987a2a',1,'initialize_STM32_interfaces(Program_Data *pd):&#160;MS_core.c']]]
];
