var searchData=
[
  ['get_5frpm_5factual_38',['get_RPM_actual',['../_m_s__signal__control_8c.html#ae109753ed1798aa1c854b69978d00e85',1,'get_RPM_actual(Program_Data *pd):&#160;MS_signal_control.c'],['../_m_s__signal__control_8h.html#ae109753ed1798aa1c854b69978d00e85',1,'get_RPM_actual(Program_Data *pd):&#160;MS_signal_control.c']]]
];
