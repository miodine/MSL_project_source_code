var searchData=
[
  ['encoder_5frpm_5fduty_5fupdate_2',['encoder_RPM_duty_update',['../_m_s__signal__control_8c.html#a21304f9f79e0331930665e4d23892e4f',1,'MS_signal_control.c']]],
  ['encoder_5frpm_5fupdate_3',['encoder_RPM_update',['../_m_s__signal__control_8h.html#ab1ecc84f4ccd1c0baf7e794d523c30e4',1,'MS_signal_control.h']]]
];
