var searchData=
[
  ['rpm_5factual_48',['RPM_actual',['../struct_program___data.html#abffe719b016075f1cd5ac50f82f0516b',1,'Program_Data']]],
  ['rpm_5freference_49',['RPM_reference',['../struct_program___data.html#ad39b0a2f06221534b9e7db57cb0aea3b',1,'Program_Data']]],
  ['rx_5fbuffer_50',['rx_buffer',['../struct_program___data.html#a0ad4bfb4c26fdc78b31fad54046ce1df',1,'Program_Data']]]
];
