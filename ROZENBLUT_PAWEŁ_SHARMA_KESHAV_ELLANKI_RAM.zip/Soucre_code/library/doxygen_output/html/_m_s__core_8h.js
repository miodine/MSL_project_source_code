var _m_s__core_8h =
[
    [ "Program_Data", "struct_program___data.html", "struct_program___data" ],
    [ "Program_Data", "_m_s__core_8h.html#a27af7a8c566015873a2e30871d6ea9c9", null ],
    [ "initialize_STM32_interfaces", "_m_s__core_8h.html#a657993cab1db72a4e524d79ab3987a2a", null ]
];