var struct_program___data =
[
    [ "HAL_PULSE_counter", "struct_program___data.html#a1c8bd10c35ac8c525665a796881338a2", null ],
    [ "PWM", "struct_program___data.html#a900674119a0bc76d7198ca0165fc7f67", null ],
    [ "RPM_actual", "struct_program___data.html#abffe719b016075f1cd5ac50f82f0516b", null ],
    [ "RPM_reference", "struct_program___data.html#ad39b0a2f06221534b9e7db57cb0aea3b", null ],
    [ "rx_buffer", "struct_program___data.html#a0ad4bfb4c26fdc78b31fad54046ce1df", null ],
    [ "tx_flag", "struct_program___data.html#a9bc203bec977ff9eca018660844ad042", null ]
];