var searchData=
[
  ['tx_5fflag_51',['tx_flag',['../struct_program___data.html#a9bc203bec977ff9eca018660844ad042',1,'Program_Data']]]
];
