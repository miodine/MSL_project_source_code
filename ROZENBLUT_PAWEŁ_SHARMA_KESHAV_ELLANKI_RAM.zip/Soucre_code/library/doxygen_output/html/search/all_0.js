var searchData=
[
  ['compensate_5ferror_0',['compensate_error',['../_m_s__signal__control_8c.html#a6fdf7020f344d899c73f618ce8567d75',1,'compensate_error(Program_Data *pd):&#160;MS_signal_control.c'],['../_m_s__signal__control_8h.html#a6fdf7020f344d899c73f618ce8567d75',1,'compensate_error(Program_Data *pd):&#160;MS_signal_control.c']]]
];
