var searchData=
[
  ['read_5fpwm_5fduty_17',['read_PWM_duty',['../_m_s__signal__control_8c.html#aa68db16714a58a700eceb3ddc19c1db6',1,'read_PWM_duty(Program_Data *pd):&#160;MS_signal_control.c'],['../_m_s__signal__control_8h.html#aa68db16714a58a700eceb3ddc19c1db6',1,'read_PWM_duty(Program_Data *pd):&#160;MS_signal_control.c']]],
  ['rpm_5factual_18',['RPM_actual',['../struct_program___data.html#abffe719b016075f1cd5ac50f82f0516b',1,'Program_Data']]],
  ['rpm_5freference_19',['RPM_reference',['../struct_program___data.html#ad39b0a2f06221534b9e7db57cb0aea3b',1,'Program_Data']]],
  ['rx_5fbuffer_20',['rx_buffer',['../struct_program___data.html#a0ad4bfb4c26fdc78b31fad54046ce1df',1,'Program_Data']]]
];
