var searchData=
[
  ['set_5fpwm_5ffrom_5frpm_21',['set_PWM_from_RPM',['../_m_s__signal__control_8c.html#a41e6d6d32d2de1cfa657572ece0883ff',1,'set_PWM_from_RPM(Program_Data *pd):&#160;MS_signal_control.c'],['../_m_s__signal__control_8h.html#a41e6d6d32d2de1cfa657572ece0883ff',1,'set_PWM_from_RPM(Program_Data *pd):&#160;MS_signal_control.c']]],
  ['set_5freference_5frpm_22',['set_reference_RPM',['../_m_s__signal__control_8c.html#a060ebfa3cd7dac5cd16c131af0c1c9c9',1,'set_reference_RPM(Program_Data *pd, uint32_t new_RPM_ref):&#160;MS_signal_control.c'],['../_m_s__signal__control_8h.html#a060ebfa3cd7dac5cd16c131af0c1c9c9',1,'set_reference_RPM(Program_Data *pd, uint32_t new_RPM_ref):&#160;MS_signal_control.c']]]
];
